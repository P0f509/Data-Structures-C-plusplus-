
#ifndef EX3TEST_HPP
#define EX3TEST_HPP

/* ************************************************************************** */

void testSimpleExercise3();

void testFullExercise3();

/* ************************************************************************** */

#endif
