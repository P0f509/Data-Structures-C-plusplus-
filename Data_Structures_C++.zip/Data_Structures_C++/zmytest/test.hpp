
#ifndef MYTEST_HPP
#define MYTEST_HPP

/* ************************************************************************** */

void startMatrixVecTest();

void startMatrixCsrTest();

/* ************************************************************************** */

#endif
